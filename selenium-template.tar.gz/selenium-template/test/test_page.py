from selenium import webdriver
from selenium.webdriver.common.by import By
from e1utils import construct_headless_chrome_driver, get_landing_page_url, wait_for_page_load


def test_nonsecret_scenario():
    landing_page = get_landing_page_url()
    driver = construct_headless_chrome_driver()

    # You can place additional test code here to drive this one test

    driver.quit()


# You may want to add additional tests....

